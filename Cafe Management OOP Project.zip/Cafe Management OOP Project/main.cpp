#include <iostream>
#include <fstream> // for file handling
#include <iomanip> // use for asterisk password mostly
#include <string>  // use for string data type
#include <conio.h>
using namespace std;

string temp_items[13];                                        // size of temp items total
double temp_price[13];                                        // size of temp price total
int item_quantity[13];                                        // size of item quantity total
int items_no[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13}; // items number one by one
string items[] = {"Burger", "Sandwich", "Pizza", "Coffee", "Fries", "Coke", "RedBull",
                  "Pasta", "Rice", "Cake", "Pancakes", "Waffles", "Donuts"}; // items name in food display menu
const double price[] = {
    499.99, 349.99, 2399.99, 169.99, 279.99, 199.99, 299,
    170, 320, 70, 149.99, 270, 189.99};                                          // price of every items
int stock[] = {100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100}; // stock of particular items
const int items_size = sizeof(items) / sizeof(items[0]);                         // calculating size of items array
double food_bill = 0;                                                            // food order bill
int items_num;                                                                   // for item selection
void MainMenu();                                                                 // main menu
void SecondMenu();                                                               // second main menu for user panel
void admin_insidepanel();                                                        // admin inside panel
class CafeManagement
{
public:
    CafeManagement()
    {
        MainMenu();
    }
};
class User
{
private:
    string password;
    string username;

public:
    User();
    void Signup();
    void login();
    void forgetPass();
};
User::User()
{
}
void User::Signup()
{
    fstream file;
    file.open("user_info.txt", ios::out | ios::in | ios::app);
    if (!file)
    {
        cout << "\n\tError Opening File:" << endl;
    }
    else
    {
        cout << "\n\tFile Created Successfully: " << endl;
        int count;
        do
        {
            cout << "\n\tEnter UserName: ";
            cin >> username;
            count = 0;
            file.clear();
            file.seekg(0, ios::beg);
            string user_name, user_pass;
            while (!file.eof())
            {
                file >> user_name >> user_pass;
                if (user_name == username)
                {
                    cout << "\n\tUsername is not valid, Please Change: " << endl;
                    count++;
                    break;
                }
            }
        } while (count != 0);
        cout << "\tEnter Password: ";
        cin >> password;
        file.clear();
        file.seekp(0, ios::end);
        file << username << " " << password << "\n";
        cout << "\n\tAccount Created Successfully:" << endl;
        file.close();
    }
}
void User::login()
{
    fstream file;
    file.open("user_info.txt", ios::in);
    if (!file)
    {
        cout << "\n\tError Occur:" << endl;
    }
    else
    {
        string file_user, file_pass;
        int count;
        do
        {
            char ch;
            cout << "\n\tEnter Username: ";
            cin >> username;
            cout << "\tEnter Password: ";
            password = "";
            while ((ch = _getch()) != 13)
            {
                cout << "*";
                // password += ch;
                password.push_back(ch);
            }
            cout << endl;
            cin.ignore();
            count = 1;
            file.clear();
            file.seekg(0, ios::beg);
            while (!file.eof())
            {
                file >> file_user >> file_pass;
                if (username == file_user && password == file_pass)
                {
                    count = 0;
                    break;
                }
            }
            if (count == 0)
            {
                cout << "\n\tLogin Successfully:" << endl;
            }
            else
            {
                cout << "\n\tWrong Credentials:" << endl;
                count = 1;
            }
        } while (count != 0);
        file.close();
    }
}
void User::forgetPass()
{
    int user_search = 0;
    do
    {
        fstream file;
        file.open("user_info.txt", ios::in);
        if (!file)
        {
            cout << "\n\tError while opening!" << endl;
            return;
        }

        ofstream temfile;
        temfile.open("temfile.txt", ios::out);
        if (!temfile)
        {
            cout << "\n\tError while opening:" << endl;
            file.close();
            return;
        }

        string user_name, new_pass;
        cout << "\n\tEnter Username: ";
        cin >> user_name;
        string username, password;
        user_search = 0;
        while (file >> username >> password)
        {
            if (user_name == username)
            {
                cout << "\tEnter new password: ";
                cin >> new_pass;
                password = new_pass;
                user_search = 1;
            }
            temfile << username << " " << password << "\n";
        }
        file.close();
        temfile.close();
        if (user_search == 0)
        {
            cout << "\n\tUsername not found. Please try again." << endl;
        }
        else
        {
            remove("user_info.txt");
            rename("temfile.txt", "user_info.txt");
            cout << "\n\tPassword updated successfully." << endl;
        }
    } while (user_search == 0);
}
class food
{
public:
    food() {};
    void DisplayFoodMenu();
    void OrderFood();
    void WriteFoodData();
    void ReadFoodMenu();
    void FoodDatabase();
    void WriteDatabaseFile();
    void ReadDatabaseFile();
};
void food::WriteDatabaseFile()
{
    ofstream out;
    out.open("food_database.txt");
    if (!out)
    {
        cout << "Unable to open file for writing." << endl;
    }
    else
    {
        for (int i = 0; i < items_size; i++)
        {
            out << items_no[i] << ' ' << items[i] << ' ' << stock[i] << endl;
        }
        out.close();
    }
}
void food::ReadDatabaseFile()
{
    ifstream in;
    in.open("food_database.txt");
    if (!in)
    {
        cout << "\n\tError while opening the file!" << endl;
    }
    else
    {
        cout << "\n\t\t\tFood Database" << endl;
        cout << "\t------------------------------------------" << endl;
        cout << "\t| No. |   Item Name   |   Stock Available |" << endl;
        cout << "\t------------------------------------------" << endl;

        for (int i = 0; i < items_size; i++)
        {
            in >> items_no[i] >> items[i] >> stock[i];
            cout << "\t| " << setw(3) << items_no[i] << " | " << setw(14) << items[i] << " | " << setw(16) << stock[i] << " |" << endl;
        }
        cout << "\t------------------------------------------" << endl;

        in.close();
    }
}
void food::DisplayFoodMenu()
{
    cout << "\n\t\t\tWelcome To Airport Food Menu:" << endl;
    cout << "\t------------------------------------------------------------" << endl;
    cout << "\t|" << left << setw(10) << "No."
         << setw(20) << "Item Name"
         << setw(21) << "Stock"
         << setw(6) << "Price" << " |" << endl;
    cout << "\t------------------------------------------------------------" << endl;
    string stock_availability[13];
    for (int i = 0; i < items_size; i++)
    {
        if (stock[i] >= 1 && stock[i] <= 100)
        {
            if (stock[i] >= 1 && stock[i] <= 20)
            {
                stock_availability[i] = "Limited";
            }
            else
            {
                stock_availability[i] = "Available";
            }
        }
        else
        {
            stock_availability[i] = "Insuficient";
        }
    }
    for (int i = 0; i < items_size; ++i)
    {
        cout << "\t|" << left << setw(10) << items_no[i]
             << setw(20) << items[i]
             << setw(17) << stock_availability[i]
             << right << setw(10) << fixed << setprecision(2) << price[i] << " |" << endl;
    }
    cout << "\t------------------------------------------------------------" << endl;
}
void food::OrderFood()
{
    char repeat;
    do
    {
        cout << "\tHow Many Items You Want To Select (e.g 1-13) ";
        cin >> items_num;
        while (items_num < 1 || items_num > 13)
        {
            cout << "\tOut of bound. Please enter a number between 1 and 13: ";
            cin >> items_num;
        }
        for (int i = 0; i < items_num; i++)
        {
            int items_no;
            cout << "\tEnter Item No. " << i + 1 << ": ";
            cin >> items_no;

            while (items_no < 1 || items_no > 13)
            {
                cout << "\tOut of bound Item No. Please select again: ";
                cin >> items_no;
            }
            cout << "\tEnter Quantity: ";
            cin >> item_quantity[i];
            if (stock[items_no - 1] < item_quantity[i])
            {
                cout << "\n\tInsuficient Stock, Please try again or told to the admin to update the Inventory! " << endl;
                i--;
            }
            else
            {
                stock[items_no - 1] -= item_quantity[i];
                temp_items[i] = items[items_no - 1];
                temp_price[i] = price[items_no - 1];
                food_bill = food_bill + item_quantity[i] * price[items_no - 1];
                WriteDatabaseFile();
            }
        }
        cout << "\n\t\t\t\t\tSelection Menu" << endl;
        cout << "\t------------------------------------------------------------" << endl;
        cout << "\t|" << left << setw(10) << "No.|"
             << setw(20) << "|Item Name|"
             << setw(21) << "|Quantity|"
             << setw(6) << "|Price" << " |" << endl;
        cout << "\t------------------------------------------------------------" << endl;
        for (int i = 0; i < items_num; i++)
        {
            cout << "\t|" << left << setw(10) << (i + 1)
                 << setw(20) << temp_items[i]
                 << setw(10) << item_quantity[i]
                 << right << setw(17) << fixed << setprecision(2) << temp_price[i] << " |" << endl;
        }
        cout << "\t------------------------------------------------------------" << endl;
        cout << "\n\t\tTotal Bill: Rs. " << fixed << setprecision(2) << food_bill << endl;
        WriteFoodData();
        cout << "\n\tN) To Exit" << endl;
        cout << "\tY) For Repeat" << endl;
        cin >> repeat;
    } while (repeat == 'Y' || repeat == 'y');
    SecondMenu();
    food_bill = 0;
}
void food::WriteFoodData()
{
    ofstream out;
    out.open("food_data.txt");
    if (!out)
    {
        cout << "\n\tFile Created Successfully: " << endl;
    }
    else
    {
        for (int i = 0; i < items_num; i++)
        {
            out << temp_items[i] << " " << item_quantity[i] << " " << temp_price[i] << "\n";
        }
    }
    out.close();
}
void food::ReadFoodMenu()
{
    ifstream in("food_data.txt");
    if (!in.is_open())
    {
        cout << "\n\tError opening the file!" << endl;
    }
    else
    {
        cout << "\n\t\tPrevious Food Orders" << endl;
        cout << "\t--------------------------------------------" << endl;
        cout << "\t|   Item Name   |   Quantity   |   Price   |" << endl;
        cout << "\t--------------------------------------------" << endl;

        string item_name;
        int quantity;
        double price;

        while (in >> item_name >> quantity >> price)
        {
            if (!in.fail())
            {
                cout << "\t| " << setw(13) << item_name << " | " << setw(12) << quantity << " | " << setw(9) << fixed << setprecision(2) << price << " |" << endl;
            }
        }

        cout << "\t--------------------------------------------" << endl;
    }
    in.close();
}
class Admin : public food
{
public:
    Admin();
    void UpdateInventory();
};
Admin::Admin()
{
}
void Admin::UpdateInventory()
{
    int item_num;
    char choice;
    int new_stock;
    cout << "\n\tCurrent Inventory:" << endl;
    ReadDatabaseFile();
    cout << "\n\tDo you want update something? (Y/N): ";
    cin >> choice;
    if (choice == 'Y' || choice == 'y')
    {
        cout << "\n\tEnter a number to update stock for items: ";
        cin >> item_num;
        while (item_num < 1 || item_num > 13)
        {
            cout << "\n\tPlease enter a number under 1-13: ";
            cin >> item_num;
        }
        for (int i = 0; i < item_num; i++)
        {
            int item_no;
            cout << "\n\tEnter Item Number to Update Stock " << i + 1 << ": ";
            cin >> item_no;
            while (item_no < 1 || item_no > items_size)
            {
                cout << "\n\tInvalid Item Number. Please enter a valid item number: ";
                cin >> item_no;
            }
        m:
            cout << "\tEnter New Stock Quantity: ";
            cin >> new_stock;
            if (new_stock <= 100 && new_stock >= 1)
            {
                stock[item_no - 1] = new_stock;
                WriteDatabaseFile();
                cout << "\n\tInventory Updated Successfully!" << endl;
            }
            else
            {
                cout << "\n\tOut of bound stock! Please enter a stock under (1-100): " << endl;
                goto m;
            }
        }
        ReadDatabaseFile();
        system("PAUSE");
        admin_insidepanel();
    }
    else
    {
        admin_insidepanel();
    }
}
void SecondMenu()
{
    User u;
    food f;
    bool flag = false;
    do
    {
        int selection;
        cout << "\n\t\t\t\t\tUSER MODE" << endl;
        cout << "\n\t\t\t-----------------------------------------" << endl;
        cout << "\t\t\t|\t\t\t\t\t|" << endl;
        cout << "\t\t\t|\t1- SIGN-UP\t\t\t|" << endl;
        cout << "\t\t\t|\t2- LOGIN\t\t\t|" << endl;
        cout << "\t\t\t|\t3- FORGET PASSWORD\t\t|" << endl;
        cout << "\t\t\t|\t4- FOOD MENU\t\t\t|" << endl;
        cout << "\t\t\t|\t5- EXIT\t\t\t\t|" << endl;
        cout << "\t\t\t|\t\t\t\t\t|" << endl;
        cout << "\t\t\t-----------------------------------------" << endl;
        cout << "\n\n\t\t\tENTER YOUR SELECTION: ";
        cin >> selection;
        if (selection == 1)
        {
            u.Signup();
            system("PAUSE");
            SecondMenu();
        }
        else if (selection == 2)
        {
            u.login();
            system("PAUSE");
            SecondMenu();
        }
        else if (selection == 3)
        {
            u.forgetPass();
            system("PAUSE");
            SecondMenu();
        }
        else if (selection == 4)
        {
            f.DisplayFoodMenu();
            char choice;
            cout << "\tDo You Want To Order Something (e.g Y/N): ";
            cin >> choice;
            if (choice == 'Y' || choice == 'y')
            {
                f.OrderFood();
            }
            else
            {
                SecondMenu();
            }
        }
        else if (selection == 5)
        {
            MainMenu();
        }
        else
        {
            cout << "\tInvalid Selection! " << endl;
            flag = true;
        }
    } while (flag);
}
void admin_insidepanel()
{
    bool flag = false;
    while (!flag)
    {
        // changing
        Admin ad;
        food f;
        int choice_insidepanel;
        cout << "\n\t\t\t\t\t    ADMIN MODE" << endl;
        cout << "\n\t\t\t-------------------------------------------------" << endl;
        cout << "\t\t\t|\t\t\t\t\t\t|" << endl;
        cout << "\t\t\t|\t1- DISPLAY FOOD PURCHASING RECORD: \t|" << endl;
        cout << "\t\t\t|\t2- FOOD DATABASE INVENTORY: \t\t|" << endl;
        cout << "\t\t\t|\t3- UPDATE INVENTORY: \t\t\t|" << endl;
        cout << "\t\t\t|\t4- EXIT: \t\t\t\t|" << endl;
        cout << "\t\t\t|\t\t\t\t\t\t|" << endl;
        cout << "\t\t\t-------------------------------------------------" << endl;
        cout << "\n\n\t\tENTER YOUR CHOICE: ";
        cin >> choice_insidepanel;
        if (choice_insidepanel == 1)
        {
            f.ReadFoodMenu();
            flag = true;
            system("PAUSE");
            admin_insidepanel();
        }
        else if (choice_insidepanel == 2)
        {
            ad.ReadDatabaseFile();
            flag = true;
            system("PAUSE");
            admin_insidepanel();
        }
        else if (choice_insidepanel == 3)
        {
            ad.UpdateInventory();
            flag = true;
        }
        else if (choice_insidepanel == 4)
        {
            MainMenu();
        }
        else
        {
            cout << "\n\tInvalid Choice! Please Try Again: " << endl;
        }
    }
}
void MainMenu()
{
    int choice;
    cout << "\n\n\t\t\t  WELCOME TO CAFE MANAGEMENT SYSTEM" << endl;
    cout << "\n\t\t\t----------------------------------------" << endl;
    cout << "\n\t\t\t|\t1)ADMIN MODE\t\t\t|" << endl;
    cout << "\t\t\t|\t2)USER MODE\t\t\t|" << endl;
    cout << "\t\t\t|\t3)EXIT\t\t\t\t|" << endl;
    cout << "\n\t\t\t-----------------------------------------" << endl;
    cout << "\n\n\t\t\tENTER YOUR CHOICE ";
    cin >> choice;
    switch (choice)
    {
    case 1:
    {
        string admin_pass = "admin";
        string admin_user = "admin";
        string temp_user, temp_pass;
    m:
        char ch;
        cout << "\n\tEnter Username: ";
        cin >> temp_user;
        temp_pass = ""; // reset temp_pass before taking the new password input
        cout << "\tEnter Password: ";
        while ((ch = getch()) != 13)
        {
            cout << "*";
            temp_pass += ch;
        }
        if (temp_user == admin_user && temp_pass == admin_pass)
        {
            cout << "\n\n\tLogin Successfully: " << endl;
            admin_insidepanel();
        }
        else
        {
            cout << "\n\tWrong Credentials, Please Try Again!" << endl;
            goto m;
        }
        break;
    }
    case 2:
    {
        SecondMenu();
        break;
    }
    case 3:
    {
        cout << "\n\n\n\t\t\tThanks, I hope w'll see you again!\n\n " << endl;
        break;
    }
    default:
        cout << "\n\tInvalid Choice: " << endl;
        break;
    }
}
int main()
{
    CafeManagement Cafe; // auto call constructor when declare object of class
    return 0;
}